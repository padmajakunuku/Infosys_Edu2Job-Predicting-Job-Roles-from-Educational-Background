**1. first  run the backend\_app.py file present in backend folder.** 



**2. then run the app.py file.** 



**3. Admin Username - admin**

         

         **Password - admin123**

